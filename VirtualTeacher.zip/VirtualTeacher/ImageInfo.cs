﻿namespace VirtualTeacher
{
    public class ImageInfo
    {
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
}
