﻿namespace VirtualTeacher.Models.DTO.CourseDTO
{
    public class CourseTopicDto
    {
        public string Topic { get; set; }
    }
}