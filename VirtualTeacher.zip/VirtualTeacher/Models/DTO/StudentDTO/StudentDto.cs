﻿using VirtualTeacher.Models.DTO.UserDTO;

namespace VirtualTeacher.Models.DTO.StudentDTO
{
    public class StudentDto : UserDto
    {
    }
}
