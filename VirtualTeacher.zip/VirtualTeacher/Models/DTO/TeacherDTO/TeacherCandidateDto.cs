﻿namespace VirtualTeacher.Models.DTO.TeacherDTO
{
    public class TeacherCandidateDto
    {
        public string Title { get; set; }
        public string Message { get; set; }
        public string Email { get; set; }
    }
}
