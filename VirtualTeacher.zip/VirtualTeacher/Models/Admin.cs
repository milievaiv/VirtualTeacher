﻿namespace VirtualTeacher.Models
{
    public class Admin : BaseUser
    {

    }
}
