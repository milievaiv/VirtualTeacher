﻿namespace VirtualTeacher.Models
{
    public enum UserRole
    {
        Student,
        Teacher,
        Administrator
    }
}
