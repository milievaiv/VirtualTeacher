﻿namespace VirtualTeacher.Models
{
    public class CourseTopicCreationRequest
    {
        public string Topic { get; set; }
    }
}
